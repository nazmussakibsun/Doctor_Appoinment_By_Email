<!DOCTYPE html>
<html>
<head>
	<title>Online Doctor Appointment System</title>
	<style>
		h1 {
  border: 2px solid green;
  padding: 25px;
  color: #5cb85c!important;
  font-family: Arial, sans-serif;
  background-color: green;
}

	</style>
	<script src="https://smtpjs.com/v3/smtp.js"></script>
</head>
<body>
	<h1 style="color: blue; font-family: Arial;">Online Doctor Appointment System</h1>

	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="border: 2px solid #eceeef; padding: 10px; width: 300px;">
    <label for="fname" style="font-weight: bold;">Patient ID/Name:</label>
    <input type="text" id="fname" name="fname" required style="border: 1px solid black; padding: 5px;"><br><br>
    <label for="lname" style="font-weight: bold;">Patient Appoinment Information :</label>
    <input type="text" id="lname" name="lname" required style="border: 1px solid black; padding: 30px;"><br><br>
    <label for="email" style="font-weight: bold;">Patient Email Address:</label>
    <input type="email" id="email" name="email" required style="border: 1px solid black; padding: 5px;"><br><br>
    <input type="submit" value="Submit" id="submit" style="background-color: #5cb85c; border-color: #17a2b8; color: white; padding: 10px;">
<input type="button" value="Back" onclick="window.history.back();" style="background-color: #d9534f;border-color: #d9534f; color: white; padding: 10px; margin-right: 10px;">
</form>


	<?php
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$fname = test_input($_POST["fname"]);
		$lname = test_input($_POST["lname"]);
		$email = test_input($_POST["email"]);

		$ebody = "<h1>Patient ID/Name: </h1>" . $fname . "<br><h1>Patient Appoinment Information: </h1>" . $lname;

		$headers = "From: softwarewise2@gmail.com\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

		// Send email using SMTPJS
		?>
		<script>
    function displayPopup() {
        alert("Email sent successfully!");
    }

    Email.send({
        SecureToken: "99dc53f0-25e0-4f42-9b56-b671e7d48dff", // add your token here
        To: '<?php echo $email; ?>', 
        From: "softwarewise2@gmail.com",
        Subject: "Patient Appoinment Information",
        Body: "<?php echo $ebody; ?>",
    }).then(displayPopup);
</script>

		<?php
	}

	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	?>
</body>
</html>
